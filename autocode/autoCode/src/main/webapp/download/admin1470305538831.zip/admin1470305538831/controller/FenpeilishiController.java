package com.chinal.emp.controller;

import org.durcframework.core.support.BsgridController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.chinal.emp.entity.Fenpeilishi;
import com.chinal.emp.entity.FenpeilishiSch;
import com.chinal.emp.service.FenpeilishiService;


@Controller
public class FenpeilishiController extends
		BsgridController<Fenpeilishi, FenpeilishiService> {
        
    @RequestMapping("/openFenpeilishi.do")
	public String openFenpeilishi() {
		return "fenpeilishi";
	}
    
	@RequestMapping("/addFenpeilishi.do")
	public ModelAndView addFenpeilishi(Fenpeilishi entity) {
		return this.add(entity);
	}

	@RequestMapping("/listFenpeilishi.do")
	public ModelAndView listFenpeilishi(FenpeilishiSch searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateFenpeilishi.do")
	public ModelAndView updateFenpeilishi(Fenpeilishi entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delFenpeilishi.do")
	public ModelAndView delFenpeilishi(Fenpeilishi entity) {
		return this.remove(entity);
	}
	
}
