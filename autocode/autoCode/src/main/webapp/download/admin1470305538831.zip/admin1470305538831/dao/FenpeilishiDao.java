package com.chinal.emp.dao;

import org.durcframework.core.dao.BaseDao;
import com.chinal.emp.entity.Fenpeilishi;

public interface FenpeilishiDao extends BaseDao<Fenpeilishi> {
}