package com.chinal.emp.service;

import org.durcframework.core.service.CrudService;
import com.chinal.emp.dao.GongzidanDao;
import com.chinal.emp.entity.Gongzidan;
import org.springframework.stereotype.Service;

@Service
public class GongzidanService extends CrudService<Gongzidan, GongzidanDao> {

}