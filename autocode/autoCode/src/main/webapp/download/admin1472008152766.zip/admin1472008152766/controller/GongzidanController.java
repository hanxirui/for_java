package com.chinal.emp.controller;

import org.durcframework.core.support.BsgridController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.chinal.emp.entity.Gongzidan;
import com.chinal.emp.entity.GongzidanSch;
import com.chinal.emp.service.GongzidanService;


@Controller
public class GongzidanController extends
		BsgridController<Gongzidan, GongzidanService> {
        
    @RequestMapping("/openGongzidan.do")
	public String openGongzidan() {
		return "gongzidan";
	}
    
	@RequestMapping("/addGongzidan.do")
	public ModelAndView addGongzidan(Gongzidan entity) {
		return this.add(entity);
	}

	@RequestMapping("/listGongzidan.do")
	public ModelAndView listGongzidan(GongzidanSch searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateGongzidan.do")
	public ModelAndView updateGongzidan(Gongzidan entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delGongzidan.do")
	public ModelAndView delGongzidan(Gongzidan entity) {
		return this.remove(entity);
	}
	
}
