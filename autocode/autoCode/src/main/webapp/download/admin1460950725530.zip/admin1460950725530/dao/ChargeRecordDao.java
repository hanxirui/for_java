package com.gecko.chargerecord.dao;

import org.durcframework.core.dao.BaseDao;
import com.gecko.chargerecord.entity.ChargeRecord;

public interface ChargeRecordDao extends BaseDao<ChargeRecord> {
}