package com.gecko.chargerecord.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

import org.durcframework.core.support.BsgridSearch;

public class ChargeRecordVo extends BsgridSearch {

    private Integer idVo;
    private String serNoVo;
    private String stateVo;
    private String pointIdVo;
    private Float chargeQuantityVo;
    private Float costVo;
    private Date startTimeVo;
    private Date endTimeVo;

    public void setIdSch(Integer idVo){
        this.idVo = idVo;
    }
    
    @ValueField(column = "c_id")
    public Integer getIdVo(){
        return this.idVo;
    }

    public void setSerNoSch(String serNoVo){
        this.serNoVo = serNoVo;
    }
    
    @ValueField(column = "c_ser_no")
    public String getSerNoVo(){
        return this.serNoVo;
    }

    public void setStateSch(String stateVo){
        this.stateVo = stateVo;
    }
    
    @ValueField(column = "c_state")
    public String getStateVo(){
        return this.stateVo;
    }

    public void setPointIdSch(String pointIdVo){
        this.pointIdVo = pointIdVo;
    }
    
    @ValueField(column = "c_point_id")
    public String getPointIdVo(){
        return this.pointIdVo;
    }

    public void setChargeQuantitySch(Float chargeQuantityVo){
        this.chargeQuantityVo = chargeQuantityVo;
    }
    
    @ValueField(column = "c_charge_quantity")
    public Float getChargeQuantityVo(){
        return this.chargeQuantityVo;
    }

    public void setCostSch(Float costVo){
        this.costVo = costVo;
    }
    
    @ValueField(column = "c_cost")
    public Float getCostVo(){
        return this.costVo;
    }

    public void setStartTimeSch(Date startTimeVo){
        this.startTimeVo = startTimeVo;
    }
    
    @ValueField(column = "c_start_time")
    public Date getStartTimeVo(){
        return this.startTimeVo;
    }

    public void setEndTimeSch(Date endTimeVo){
        this.endTimeVo = endTimeVo;
    }
    
    @ValueField(column = "c_end_time")
    public Date getEndTimeVo(){
        return this.endTimeVo;
    }


}