package com.gecko.chargerecord.controller;

import org.durcframework.core.support.BsgridController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gecko.chargerecord.entity.ChargeRecord;
import com.gecko.chargerecord.entity.ChargeRecordVo;
import com.gecko.chargerecord.service.ChargeRecordService;


@Controller
public class ChargeRecordController extends
		BsgridController<ChargeRecord, ChargeRecordService> {

	@RequestMapping("/addChargeRecord.do")
	public ModelAndView addChargeRecord(ChargeRecord entity) {
		return this.add(entity);
	}

	@RequestMapping("/listChargeRecord.do")
	public ModelAndView listChargeRecord(ChargeRecordVo searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateChargeRecord.do")
	public ModelAndView updateChargeRecord(ChargeRecord entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delChargeRecord.do")
	public ModelAndView delChargeRecord(ChargeRecord entity) {
		return this.remove(entity);
	}
	
}
