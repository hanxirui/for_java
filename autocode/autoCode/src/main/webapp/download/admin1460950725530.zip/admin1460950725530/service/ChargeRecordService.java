package com.gecko.chargerecord.service;

import org.durcframework.core.service.CrudService;
import com.gecko.chargerecord.dao.ChargeRecordDao;
import com.gecko.chargerecord.entity.ChargeRecord;
import org.springframework.stereotype.Service;

@Service
public class ChargeRecordService extends CrudService<ChargeRecord, ChargeRecordDao> {

}