package com.gecko.chargerecord.entity;

import java.util.Date;

/**
  
*/
public class ChargeRecord {
	// 
	private int id;
	// 序号
	private String serNo;
	// 状态
	private String state;
	// 充电桩ID
	private String pointId;
	// 充电量（度）
	private float chargeQuantity;
	// 金额（元）
	private float cost;
	// 
	private Date startTime;
	// 
	private Date endTime;

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return this.id;
	}

	public void setSerNo(String serNo){
		this.serNo = serNo;
	}

	public String getSerNo(){
		return this.serNo;
	}

	public void setState(String state){
		this.state = state;
	}

	public String getState(){
		return this.state;
	}

	public void setPointId(String pointId){
		this.pointId = pointId;
	}

	public String getPointId(){
		return this.pointId;
	}

	public void setChargeQuantity(float chargeQuantity){
		this.chargeQuantity = chargeQuantity;
	}

	public float getChargeQuantity(){
		return this.chargeQuantity;
	}

	public void setCost(float cost){
		this.cost = cost;
	}

	public float getCost(){
		return this.cost;
	}

	public void setStartTime(Date startTime){
		this.startTime = startTime;
	}

	public Date getStartTime(){
		return this.startTime;
	}

	public void setEndTime(Date endTime){
		this.endTime = endTime;
	}

	public Date getEndTime(){
		return this.endTime;
	}

}