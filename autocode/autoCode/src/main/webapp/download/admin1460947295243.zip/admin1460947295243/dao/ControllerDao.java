package com.gecko.controller.dao;

import org.durcframework.core.dao.BaseDao;
import com.gecko.controller.entity.Controller;

public interface ControllerDao extends BaseDao<Controller> {
}