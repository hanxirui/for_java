package com.gecko.controller.service;

import org.durcframework.core.service.CrudService;
import com.gecko.controller.dao.ControllerDao;
import com.gecko.controller.entity.Controller;
import org.springframework.stereotype.Service;

@Service
public class ControllerService extends CrudService<Controller, ControllerDao> {

}