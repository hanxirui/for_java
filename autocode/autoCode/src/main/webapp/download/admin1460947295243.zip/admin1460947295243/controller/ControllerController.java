package com.gecko.controller.controller;

import org.durcframework.core.support.BsgridController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gecko.controller.entity.Controller;
import com.gecko.controller.entity.ControllerVo;
import com.gecko.controller.service.ControllerService;


@Controller
public class ControllerController extends
		BsgridController<Controller, ControllerService> {

	@RequestMapping("/addController.do")
	public ModelAndView addController(Controller entity) {
		return this.add(entity);
	}

	@RequestMapping("/listController.do")
	public ModelAndView listController(ControllerVo searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateController.do")
	public ModelAndView updateController(Controller entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delController.do")
	public ModelAndView delController(Controller entity) {
		return this.remove(entity);
	}
	
}
