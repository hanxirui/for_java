package com.gecko.chargectl.dao;

import org.durcframework.core.dao.BaseDao;
import com.gecko.chargectl.entity.ChargeCtl;

public interface ChargeCtlDao extends BaseDao<ChargeCtl> {
}