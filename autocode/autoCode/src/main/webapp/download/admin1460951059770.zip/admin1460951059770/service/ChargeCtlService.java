package com.gecko.chargectl.service;

import org.durcframework.core.service.CrudService;
import com.gecko.chargectl.dao.ChargeCtlDao;
import com.gecko.chargectl.entity.ChargeCtl;
import org.springframework.stereotype.Service;

@Service
public class ChargeCtlService extends CrudService<ChargeCtl, ChargeCtlDao> {

}