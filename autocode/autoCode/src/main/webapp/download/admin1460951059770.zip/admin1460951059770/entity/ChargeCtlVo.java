package com.gecko.chargectl.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

import org.durcframework.core.support.BsgridSearch;

public class ChargeCtlVo extends BsgridSearch {

    private Integer idVo;
    private String sernoVo;
    private String stateVo;
    private String conrollerIdVo;
    private String stationIdVo;
    private Integer lockNumVo;
    private Date addTimeVo;
    private Date lastKaVo;

    public void setIdSch(Integer idVo){
        this.idVo = idVo;
    }
    
    @ValueField(column = "c_id")
    public Integer getIdVo(){
        return this.idVo;
    }

    public void setSernoSch(String sernoVo){
        this.sernoVo = sernoVo;
    }
    
    @ValueField(column = "c_serNo")
    public String getSernoVo(){
        return this.sernoVo;
    }

    public void setStateSch(String stateVo){
        this.stateVo = stateVo;
    }
    
    @ValueField(column = "c_state")
    public String getStateVo(){
        return this.stateVo;
    }

    public void setConrollerIdSch(String conrollerIdVo){
        this.conrollerIdVo = conrollerIdVo;
    }
    
    @ValueField(column = "c_conroller_Id")
    public String getConrollerIdVo(){
        return this.conrollerIdVo;
    }

    public void setStationIdSch(String stationIdVo){
        this.stationIdVo = stationIdVo;
    }
    
    @ValueField(column = "c_station_id")
    public String getStationIdVo(){
        return this.stationIdVo;
    }

    public void setLockNumSch(Integer lockNumVo){
        this.lockNumVo = lockNumVo;
    }
    
    @ValueField(column = "c_lock_num")
    public Integer getLockNumVo(){
        return this.lockNumVo;
    }

    public void setAddTimeSch(Date addTimeVo){
        this.addTimeVo = addTimeVo;
    }
    
    @ValueField(column = "c_add_time")
    public Date getAddTimeVo(){
        return this.addTimeVo;
    }

    public void setLastKaSch(Date lastKaVo){
        this.lastKaVo = lastKaVo;
    }
    
    @ValueField(column = "c_last_ka")
    public Date getLastKaVo(){
        return this.lastKaVo;
    }


}