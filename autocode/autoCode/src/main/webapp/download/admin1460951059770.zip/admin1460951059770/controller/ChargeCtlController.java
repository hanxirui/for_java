package com.gecko.chargectl.controller;

import org.durcframework.core.support.BsgridController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gecko.chargectl.entity.ChargeCtl;
import com.gecko.chargectl.entity.ChargeCtlVo;
import com.gecko.chargectl.service.ChargeCtlService;


@Controller
public class ChargeCtlController extends
		BsgridController<ChargeCtl, ChargeCtlService> {

	@RequestMapping("/addChargeCtl.do")
	public ModelAndView addChargeCtl(ChargeCtl entity) {
		return this.add(entity);
	}

	@RequestMapping("/listChargeCtl.do")
	public ModelAndView listChargeCtl(ChargeCtlVo searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateChargeCtl.do")
	public ModelAndView updateChargeCtl(ChargeCtl entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delChargeCtl.do")
	public ModelAndView delChargeCtl(ChargeCtl entity) {
		return this.remove(entity);
	}
	
}
