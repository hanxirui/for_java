package com.gecko.chargectl.entity;

import java.util.Date;

/**
  
*/
public class ChargeCtl {
	// 
	private int id;
	// 序号
	private String serno;
	// 状态
	private String state;
	// 控制器ID
	private String conrollerId;
	// 站点
	private String stationId;
	// 车辆锁数量
	private int lockNum;
	// 添加时间
	private Date addTime;
	// 最近一次心跳
	private Date lastKa;

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return this.id;
	}

	public void setSerno(String serno){
		this.serno = serno;
	}

	public String getSerno(){
		return this.serno;
	}

	public void setState(String state){
		this.state = state;
	}

	public String getState(){
		return this.state;
	}

	public void setConrollerId(String conrollerId){
		this.conrollerId = conrollerId;
	}

	public String getConrollerId(){
		return this.conrollerId;
	}

	public void setStationId(String stationId){
		this.stationId = stationId;
	}

	public String getStationId(){
		return this.stationId;
	}

	public void setLockNum(int lockNum){
		this.lockNum = lockNum;
	}

	public int getLockNum(){
		return this.lockNum;
	}

	public void setAddTime(Date addTime){
		this.addTime = addTime;
	}

	public Date getAddTime(){
		return this.addTime;
	}

	public void setLastKa(Date lastKa){
		this.lastKa = lastKa;
	}

	public Date getLastKa(){
		return this.lastKa;
	}

}