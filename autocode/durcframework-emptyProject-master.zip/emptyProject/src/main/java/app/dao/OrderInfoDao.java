package app.dao;

import org.durcframework.core.dao.BaseDao;
import app.entity.OrderInfo;

public interface OrderInfoDao extends BaseDao<OrderInfo> {
}