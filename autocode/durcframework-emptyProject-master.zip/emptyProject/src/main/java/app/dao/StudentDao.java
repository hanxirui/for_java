package app.dao;

import org.durcframework.core.dao.BaseDao;

import app.entity.Student;

/**
 * DAO类,只需简单继承父类即可
 */
public interface StudentDao extends BaseDao<Student> {}
