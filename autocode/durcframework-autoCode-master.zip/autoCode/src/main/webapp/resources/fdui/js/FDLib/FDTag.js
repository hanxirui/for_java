/**
 * @private
 */
var FDTag = {
	DIV:"div"
	,EM:"em"
	,A:"a"
	,INPUT:"input"
	,TEXTAREA:"textarea"
	,SPAN:"span"
	,UL:"ul"
	,LI:"li"
	,TABLE:"table"
	,TBODY:"tbody"
	,IFRAME:"iframe"
	,TH:"th"
	,LABEL:"label"
	,SELECT:"select"
	,BUTTON:"button"
};