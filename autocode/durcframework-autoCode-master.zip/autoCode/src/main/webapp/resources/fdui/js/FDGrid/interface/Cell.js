/**
 * 表格单元格接口
 * @private
 */
var Cell = FDLib.createInterface([
	'buildCellData'
]);