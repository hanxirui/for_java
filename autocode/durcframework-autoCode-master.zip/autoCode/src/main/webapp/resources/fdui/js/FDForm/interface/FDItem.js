/**
 * 具有item属性控件的接口,只提供方法<br>
 * 方法列表:<br>
 * <pre>
setItems
getItems
 * </pre>
 * @class
 */
var FDItem = FDLib.createInterface([
	'setItems'
	,'getItems'
]);