/**
 * 视图层的接口
 * 
 * @private
 *
 */
var View = FDLib.createInterface([
	'processData'
]);