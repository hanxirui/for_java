/**
 * model层接口
 * @private
 */
var Model = FDLib.createInterface([
	'postData'
]);