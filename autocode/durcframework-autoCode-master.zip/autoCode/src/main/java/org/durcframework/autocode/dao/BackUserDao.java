package org.durcframework.autocode.dao;

import org.durcframework.autocode.entity.BackUser;
import org.durcframework.core.dao.BaseDao;

public interface BackUserDao extends BaseDao<BackUser> {

}
