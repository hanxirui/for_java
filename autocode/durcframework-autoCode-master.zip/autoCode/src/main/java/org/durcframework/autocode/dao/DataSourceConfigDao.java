package org.durcframework.autocode.dao;

import org.durcframework.autocode.entity.DataSourceConfig;
import org.durcframework.core.dao.BaseDao;

public interface DataSourceConfigDao extends BaseDao<DataSourceConfig> {

}
