package org.durcframework.autocode.dao;

import org.durcframework.autocode.entity.TemplateConfig;
import org.durcframework.core.dao.BaseDao;

public interface TemplateConfigDao extends BaseDao<TemplateConfig> {

}
